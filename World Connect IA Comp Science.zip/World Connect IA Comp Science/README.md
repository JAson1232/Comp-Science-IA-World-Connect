# School-Management-System-Inspiration
A Java Swing Application inspiration using Netbeans and Swing framework. Hover through tiles and get a nice look.

![alt text](https://github.com/k33ptoo/School-Management-System-Inspiration/blob/master/img1.png)

