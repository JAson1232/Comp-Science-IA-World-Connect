/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import static main.Login.c;

/**
 *
 * @author Jason Somoglou
 */
public class Event implements java.io.Serializable{
    public int row;
    public int col;
    public String text;
    public static ArrayList<Event> Events = new ArrayList();
    public Event(int row,int col,String text){
        this.row = row;
        this.col = col;
        this.text = text;
    }
    
    public static void addEvent(Event event){
        Events.add(event);
    }
    
    public static String findEvent(int row, int col){
        for(Event event : Events){
            if(event.row == row && event.col == col){
                return event.text; 
            }
        }
        return null;
    }
    
    
    public static Event EventPos(int row,int col){
        for(Event event : Events){
            if(event.row == row && event.col == col){
                return event; 
            }
        }
        return null;
    }
    public static void removeEvent(Event event){
        Events.remove(event);
    }
    public  void setText(String text){
        this.text = text;
    }
    
    
   
    
    
    
}
