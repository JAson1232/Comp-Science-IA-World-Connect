/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;
import java.util.*;
import static sun.util.locale.LocaleUtils.isEmpty;
/**
 *
 * @author Jason Somoglou
 */
public class User implements java.io.Serializable{
    public String Name;
    public String Surname;
    private String Password;
    public String Email;
    public String PhoneNum;
    public static HashMap<User,Integer> Users = new HashMap<User,Integer>();
    private static String[] Names = new String[100];
    
    public User(String Name,String Surname, String Password,String Email,String PhoneNum){
        this.Name = Name;
        this.Password = Password;
        this.Surname = Surname;
        this.Email = Email;
        this.PhoneNum = PhoneNum;
    }
    
    //Username Setters and other functions
    
    
    public void setName(String Name){
        this.Name = Name;
    }
    
    public static void addName(String Name, int index){
        Names[index] = Name;
    }
    public static String[] getNames(){
        return Names;
    }
    public String getName(){
        return this.Name;
    }
    
    //Password Setters and other functions
    
    public void setPassword(String Password){
        this.Password = Password;
    }
    public String getPassword(){
        return this.Password;
    }
    
    
    //Main Functions for Storing Users
    
    public static void addUser(User user,int index){
        Users.put(user, index);
    }
    public static boolean findUser(String Name){
        boolean exists = false;
        for(int i = 0;i<Names.length;i++){
            if(Names[i] == Name){
                exists = true;
            }
        }
        return exists;
    }
    
    public static int findUserLogin(String Name, String Password){
        for(User user : Users.keySet()){
            if(user.getName().contains(Name) && user.getPassword().contains(Password)){
                return 1;
            }
        }
        return 0;
    }
    public static void removeUser(String Name){
        for(User user: Users.keySet()){
            if(user.getName().contains(Name)){
                Users.remove(user);
        }
        }
    }
    public static void editUser(String Name , String Name1,String Surname, String Email,String PhoneNum){
        for(User user: Users.keySet()){
            if(user.getName().contains(Name)){
                if(isEmpty(Name1)){
                
                }else{
                  user.Name = Name1;  
                }
                if(isEmpty(Surname)){
               
                }else{
                user.Surname = Surname;
                }
                if(isEmpty(Email)){
                  
                }else{
                 user.Email = Email;     
                }
                if(isEmpty(PhoneNum)){
                
                }else{
                   user.PhoneNum = PhoneNum; 
                }
        }
        }
    }
    

   
    
    
    
    
    
    
    
    
    
    
}
