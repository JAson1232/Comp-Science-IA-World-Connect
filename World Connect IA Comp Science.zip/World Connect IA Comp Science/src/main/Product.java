/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.io.Serializable;
import java.util.ArrayList;
import static sun.util.locale.LocaleUtils.isEmpty;

/**
 *
 * @author Jason Somoglou
 */
public class Product implements Serializable{
    private String Manager;
    private String Name;
    private ArrayList<User> Employees = new ArrayList<>();
    public static ArrayList<Product> Products = new ArrayList<>();
    
    public Product(String Name, String Manager, ArrayList<User> Employees){
        this.Manager = Manager;
        this.Name = Name;
        this.Employees = Employees;
    }
    public String getManager(){
        return this.Manager;
    }
    public void setManager(String Manager){
        this.Manager = Manager;
    }
    public String getName(){
        return this.Name;
    }
    public void setName(String Name){
        this.Name = Name;
    }
    public void addEmployee(User user){
        this.Employees.add(user);
    }
    public void removeEmployee(User user){
        this.Employees.remove(user);
    }
    public static void addProduct(Product product){
        Products.add(product);
    }
    public static void removeProduct(String Name){
        for(Product product : Products){
            if(product.Name.contains(Name)){
                Products.remove(product);
        }
        }
    }
    public static void editProduct(String Name , String Name1,String Surname){
        for(Product product : Products){
            if(product.Name.contains(Name)){
                if(isEmpty(Name1)){
                    
                }else{
                product.Name = Name1;
                }
                if(isEmpty(Surname)){
                    
                }else{
                product.Manager = Surname;
                }
            }
        }
        }
}
